# Tombolenkovač

## Installation

## Usage

To generate tickets, run

```bash
tombolenkovac --gen
```

and follow the instructions. It will create tombolenky.pdf.


To draw winning tickets, run

```bash
tombolenkovac --draw
```
and scan winning tickets until all prizes runs out.

To check if ticket won, run

```bash
tombolenkovac --check
```
and scan the ticket. It will return the number of prize, or it says it is not a winning ticket.