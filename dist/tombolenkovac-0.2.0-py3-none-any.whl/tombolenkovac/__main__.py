import tombolenkovac

if __name__ == '__main__':
    tombolenkovac.main.main()